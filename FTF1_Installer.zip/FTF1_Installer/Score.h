//
// Created by Dreamcatcher on 11/16/2017.
//

#ifndef FTF1_SCORE_H
#define FTF1_SCORE_H
#include<SDL.h>
#include<iostream>
#include<cstring>
#include<SDL_ttf.h>
#include<fstream>
#include"saveFileCreator.h"

#define fps 60

void cap_framerate(Uint32 starting_tick) {
    if ((1000 / fps) > SDL_GetTicks() - starting_tick) {
        SDL_Delay(1000 / fps - (SDL_GetTicks() - starting_tick));
    }
}

class Score {
    private:
    SDL_Window *saveWindow = nullptr;
    SDL_Renderer *renderer = nullptr;
    SDL_Surface* saveDisplay;
    SDL_Texture* saveText;
    TTF_Font* tomnr;
    SDL_Color White;
    std::string nameInput;

    public:
        std::string playerInputConsole();



    Score(){
        if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
            std::cout << "Video Initialization Error" << SDL_GetError() << std::endl;
        TTF_Init();
        saveWindow = SDL_CreateWindow("Scoreboard Name Entry", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 600, 150, SDL_WINDOW_SHOWN);
        renderer = SDL_CreateRenderer(saveWindow, -1, SDL_RENDERER_ACCELERATED);
        tomnr = TTF_OpenFont("../Resources/Assets/fonts/tomnr.ttf", 24);
        if (tomnr == NULL) {
            SDL_SetWindowTitle(saveWindow, "font didn't load");
        }
        White = {255, 255, 255};


    }

    ~Score() {
        SDL_Quit();
        SDL_FreeSurface(saveDisplay);
        SDL_DestroyTexture(saveText);
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(saveWindow);
    }



};

std::string Score::playerInputConsole() {



    SDL_Event event;
    bool isTyping = true;
    nameInput = "";
    int i = 0;

    while (isTyping) {
        Uint32 ticks;
        ticks = SDL_GetTicks();
        while (SDL_PollEvent(&event)) {


            if ((event.type == SDL_KEYDOWN && event.key.keysym.scancode == SDL_SCANCODE_RETURN) || ( event.type == SDL_KEYDOWN && event.key.keysym.scancode == SDL_SCANCODE_KP_ENTER)) {
                isTyping = false;

            }

            if (event.type == SDL_KEYDOWN) {
                switch (event.key.keysym.scancode) {
                    case SDL_SCANCODE_A:
                        if(nameInput.length() < 20)
                            nameInput += "A";
                        break;
                    case SDL_SCANCODE_B:
                        if(nameInput.length() < 20)
                            nameInput += "B";
                        break;
                    case SDL_SCANCODE_C:
                        if(nameInput.length() < 20)
                            nameInput += "C";
                        break;
                    case SDL_SCANCODE_D:
                        if(nameInput.length() < 20)
                            nameInput += "D";
                        break;
                    case SDL_SCANCODE_E:
                        if(nameInput.length() < 20)
                            nameInput += "E";
                        break;
                    case SDL_SCANCODE_F:
                        if(nameInput.length() < 20)
                            nameInput += "F";
                        break;
                    case SDL_SCANCODE_G:
                        if(nameInput.length() < 20)
                            nameInput += "G";
                        break;
                    case SDL_SCANCODE_H:
                        if(nameInput.length() < 20)
                            nameInput += "H";
                        break;
                    case SDL_SCANCODE_I:
                        if(nameInput.length() < 20)
                            nameInput += "I";
                        break;
                    case SDL_SCANCODE_J:
                        if(nameInput.length() < 20)
                            nameInput += "J";
                        break;
                    case SDL_SCANCODE_K:
                        if(nameInput.length() < 20)
                            nameInput += "K";
                        break;
                    case SDL_SCANCODE_L:
                        if(nameInput.length() < 20)
                            nameInput += "L";
                        break;
                    case SDL_SCANCODE_M:
                        if(nameInput.length() < 20)
                            nameInput += "M";
                        break;
                    case SDL_SCANCODE_N:
                        if(nameInput.length() < 20)
                            nameInput += "N";
                        break;
                    case SDL_SCANCODE_O:
                        if(nameInput.length() < 20)
                            nameInput += "O";
                        break;
                    case SDL_SCANCODE_P:
                        if(nameInput.length() < 20)
                            nameInput += "P";
                        break;
                    case SDL_SCANCODE_Q:
                        if(nameInput.length() < 20)
                            nameInput += "Q";
                        break;
                    case SDL_SCANCODE_R:
                        if(nameInput.length() < 20)
                            nameInput += "R";
                        break;
                    case SDL_SCANCODE_S:
                        if(nameInput.length() < 20)
                            nameInput += "S";
                        break;
                    case SDL_SCANCODE_T:
                        if(nameInput.length() < 20)
                            nameInput += "T";
                        break;
                    case SDL_SCANCODE_U:
                        if(nameInput.length() < 20)
                            nameInput += "U";
                        break;
                    case SDL_SCANCODE_V:
                        if(nameInput.length() < 20)
                            nameInput += "V";
                        break;
                    case SDL_SCANCODE_W:
                        if(nameInput.length() < 20)
                            nameInput += "W";
                        break;
                    case SDL_SCANCODE_X:
                        if(nameInput.length() < 20)
                            nameInput += "X";
                        break;
                    case SDL_SCANCODE_Y:
                        if(nameInput.length() < 20)
                            nameInput += "Y";
                        break;
                    case SDL_SCANCODE_Z:
                        if(nameInput.length() < 20)
                            nameInput += "Z";
                        break;
                    case SDL_SCANCODE_1:
                        if(nameInput.length() < 20)
                            nameInput += "1";
                        break;
                    case SDL_SCANCODE_2:
                        if(nameInput.length() < 20)
                            nameInput += "2";
                        break;
                    case SDL_SCANCODE_3:
                        if(nameInput.length() < 20)
                            nameInput += "3";
                        break;
                    case SDL_SCANCODE_4:
                        if(nameInput.length() < 20)
                            nameInput += "4";
                        break;
                    case SDL_SCANCODE_5:
                        if(nameInput.length() < 20)
                            nameInput += "5";
                        break;
                    case SDL_SCANCODE_6:
                        if(nameInput.length() < 20)
                            nameInput += "6";
                        break;
                    case SDL_SCANCODE_7:
                        if(nameInput.length() < 20)
                            nameInput += "7";
                        break;
                    case SDL_SCANCODE_8:
                        if(nameInput.length() < 20)
                            nameInput += "8";
                        break;
                    case SDL_SCANCODE_9:
                        if(nameInput.length() < 20)
                            nameInput += "9";
                        break;
                    case SDL_SCANCODE_0:
                        if(nameInput.length() < 20)
                            nameInput += "0";
                        break;
                    case SDL_SCANCODE_BACKSPACE:
                        if(nameInput.length() != 0)
                        nameInput.pop_back();
                        break;



                }
            }

            saveDisplay = TTF_RenderText_Solid(tomnr, &nameInput[0], White);
            saveText = SDL_CreateTextureFromSurface(renderer, saveDisplay);
            SDL_RenderCopy(renderer, saveText, NULL, NULL);
            SDL_RenderPresent(renderer);
            SDL_RenderClear(renderer);


            cap_framerate(ticks);
        }


    }
    return nameInput;
}




#endif //FTF1_SCORE_H
