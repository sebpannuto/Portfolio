//
// Created by mattr on 10/11/2017.
//
#ifndef FTF1_ENEMY_H
#define FTF1_ENEMY_H

#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include <ctime>
#include "character.h"






class Enemy : public Character{
    private:

    bool touchable();
    void collision(Entity &e);


    int max_step=(rand()%3+1)*60;
    int step_count=0;
    static char rand_dir[4];
    char old_dir;
    int collidetime=0;


    public:
    Enemy(){};
    ~Enemy(){};
    Enemy(int x, int y, SDL_Renderer *rend, std::string type);
    void process_AI();
    void animate();
};
char Enemy::rand_dir[4]={'L', 'R', 'U', 'D'};

/*
 * Enemy::Enemy(int x, int y, SDL_Renderer *rend, char* path) : Character(x,y,rend,path)
 *
 * receives and sets location and of enemy on world, the renderer for the enemy and the takes the path
 * for the enemy sprite sheet. sends these parameters to the character constructor
 *
 * instantiates:
 *      disp_rect
 *      sprite:             rect getting the frame from the sprite sheet
 *      dir:                2 char string for direction of player movement dir[0]=L/R, dir[1]=U/D
 *
 * hardcoded:
 *      num_of_frames:   the number of frames on the sprite sheet
 *      num_of_dir:      the number of directions on the sprite sheet
 *
 * parameters:
 *  int x:                   x coordinate of player location
 *  int y:                   y coordinate of player location
 *  SDL_Renderer *rend:     main window renderer
 *  char* path:             path of the sprite sheet
 */

Enemy::Enemy(int x, int y, SDL_Renderer *rend, std::string type) : Character(x,y,rend,type){
    num_of_dir=4;
    num_of_frames=5;

    rect.w= 32;
    rect.h= 48;                                              //use pixels dimensions of sprite
    disp_rect=rect;


    SDL_GetRendererOutputSize(renderer, &lvl.w, &lvl.h);                //get size of window not background image
    SDL_QueryTexture(texture, NULL, NULL, &sheet_w, &sheet_h);

    sprite={0,0,sheet_w/num_of_frames-5, sheet_h/num_of_dir};

    step_dis=2;
    old_dir=dir[0]=rand_dir[rand()%4];

    rect.w-=8;
    rect.h-=10;
}

/*
 * bool Enemy::touchable()
 *
 * returns whether the enemy is able to interact or not
 */
bool Enemy::touchable(){
    return true;
}

/*
 * void Enemy::collision(Entity &e)
 *
 * decides effects for collision with other entities
 *
 * parameters:
 *      Entity &e: entity enemy collided with
 */
void Enemy::collision(Entity &e){

    collidetime++;

    if(collidetime>=4) {                //check for movement && slow down sprite frame rate

        old_dir=rand_dir[rand()%4];
        collidetime=0;

    }
}

/*
 * void Enemy::process_AI()
 *
 * sets the next enemy action and movement
 *
 * parameters: none
 */

void Enemy::process_AI() {
    clear_dir();

    if(bind_to_lvl())
        old_dir=rand_dir[rand()%4];

    if(step_count<max_step){
        step_count++;
        dir[0] = dir[1] = old_dir;

    }else{
        step_count=0;
        dir[0] = dir[1] = old_dir = rand_dir[rand()%4];
    }

    mov=true;

    Debug_Output2+=std::to_string(max_step);
    Debug_Output2+=" ";
 //   Debug_Output2+=std::to_string(rect.y);
}


/*
* void Player::animate()
*
*  manages animation across sprite sheet with sprite rect
*  limits animation rate of sprite
 *
 *  parameters: none
*/
void Enemy::animate() {

    if(dir[0]=='L')
        sprite.y=0;
    if(dir[0]=='R')
        sprite.y=sprite.h*2;
    if(dir[1]=='U')
        sprite.y=sprite.h*3;
    if(dir[1]=='D')
        sprite.y=sprite.h*1;

    frametime++;
    if(frametime>=4) {                //check for movement && slow down sprite frame rate

            sprite.x += sprite.w;                   //advance across sprite sheet

            if (sprite.x + sprite.w >= sheet_w) {
                sprite.x = 0;
            }
        frametime=0;
    }
}
#endif //FTF1_ENEMY_H
