To Install:

Run chmod +x on setup.sh to allow it to be executable
Run sudo setup.sh

Setup script will create a bash command FTF1 to run the game
