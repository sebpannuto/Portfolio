//
// Created by mattr on 10/24/2017.
//

#ifndef FTF1_DEBUGCONSOLE_H
#define FTF1_DEBUGCONSOLE_H

#include <SDL.h>
#include <iostream>
#include <SDL_ttf.h>

static std::string Debug_Output;
static std::string Debug_Output2;


class DebugConsole {
private:
    SDL_Window *DebugWindow = nullptr;
    SDL_Renderer  *DebugRenderer = nullptr;
    SDL_Surface* debugger;
    SDL_Texture* text;
    TTF_Font* tomnr;
    SDL_Color White;
    Uint32 winID;

public:

    void print(std::string output);

    DebugConsole(int x, int y){
        if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
            std::cout << "Video Initialization Error" << SDL_GetError() << std::endl;
        TTF_Init();
        DebugWindow = SDL_CreateWindow("Debug Console",x, y, 600, 150, SDL_WINDOW_HIDDEN);
        DebugRenderer = SDL_CreateRenderer(DebugWindow, -1, SDL_RENDERER_ACCELERATED);
        tomnr = TTF_OpenFont("../Resources/Assets/fonts/OpenSans-Regular.ttf", 24);
        if(tomnr == NULL) {
            SDL_SetWindowTitle(DebugWindow, "font didn't load");
        }
        White = {255, 255, 255};

        winID=SDL_GetWindowID(DebugWindow);

    }

    ~DebugConsole(){
        SDL_DestroyRenderer(DebugRenderer);
        SDL_DestroyWindow(DebugWindow);
    }

    Uint32 getID(){return winID;}
};



void DebugConsole::print(std::string output){

    std::string newCOut = output;
    debugger = TTF_RenderText_Solid(tomnr, newCOut.c_str() , White);
    text = SDL_CreateTextureFromSurface(DebugRenderer, debugger);
    SDL_RenderCopy(DebugRenderer, text, NULL, NULL);
    SDL_RenderPresent(DebugRenderer);
    SDL_RenderClear(DebugRenderer);
    SDL_FreeSurface(debugger);
    SDL_DestroyTexture(text);

   //Debug_Output="";
}




#endif //FTF1_DEBUGCONSOLE_H
