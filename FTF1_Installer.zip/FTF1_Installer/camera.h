
#ifndef SDL_TEST_CAMERA_H
#define SDL_TEST_CAMERA_H

#include <iostream>
#include <SDL.h>
#include <SDL_image.h>

class Camera{
    private:

    int window_width;
    int window_height;
    int level_width;
    int level_height;
    int level_x;
    int level_y;

    SDL_Rect rect;

    public:
    Camera(){};
    Camera(int win_w, int win_h, SDL_Rect level);
    void setPos(SDL_Rect player_rect);
    void setWindowSize(int w, int h);
    void update();
    SDL_Rect getRect(){return rect;}
    SDL_Rect* getRectADDR(){return &rect;}
    void setLevelSize(SDL_Rect lvl);

};


/*
 * Camera::Camera(int win_w, int win_h, int lvl_w,int lvl_h)
 *
 * retrieves and sets dimensions of the window and the world
 *
 * parameters:
 *  int win_w: width of the main window
 *  int win_h: height of the window
 *  int lvl_w: width of the world
 *  int lvl_h: height of the world
 */

Camera::Camera(int win_w, int win_h, SDL_Rect level){
    window_width=win_w;
    window_height=win_h;
    level_x=level.x;
    level_y=level.y;
    level_width=level.w;
    level_height=level.h;

    rect={level.x,level.y,window_width,window_height};
}

/*
 * void Camera::setPos(SDL_Rect player_rect)
 * 
 * sets the position of the camera on the world
 * 
 * parameters:
 *  SDL_rect player_rect: rect of players position
 */
void Camera::setPos(SDL_Rect player_rect){
    
    rect.x=player_rect.x+player_rect.w/2-(window_width/2);
    rect.y=player_rect.y+player_rect.h/2-(window_height/2);
}



void Camera::setWindowSize(int w, int h) {
    window_width=w;
    window_height=h;
}


/*
 * void Camera::update()
 *
 * adjusts the camera position to center the player on screen.
 * stops the camera at the edges of the world
 */
void Camera::update() {

    if(rect.x<0)                          //stop camera at edges
        rect.x = 0;
    if(rect.y<0)
        rect.y = 0;
    if(rect.x+rect.w>= level_width+2*level_x)
        rect.x=level_width-rect.w+2*level_x;
    if(rect.y+rect.h>= level_height+2*level_y)
        rect.y=level_height-rect.h+2*level_y;
}

void Camera::setLevelSize(SDL_Rect lvl) {
    level_x=lvl.x;
    level_y=lvl.y;
    level_width=lvl.w;
    level_height=lvl.h;
}




#endif //SDL_TEST_CAMERA_H



