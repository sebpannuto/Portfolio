//
// Created by mattr on 11/18/2017.
//

#ifndef FTF1_ROOM_H
#define FTF1_ROOM_H

#include <cstdlib>
#include <string>

class Room{
public:
    Room();
    Room(int newRoomNumber, int newX, int newY, std::string newTunnelLocation);
    int getRoomNumber();
    int getX();
    int getY();
    std::string getTunnels();
    std::string defineTunnels(int RoomID, int rooms);
private:
    int RoomNumber;
    int X;
    int Y;
    std::string TunnelLocation;
};

Room::Room()=default;

Room::Room(int newRoomNumber, int newX, int newY, std::string newTunnelLocation){
    RoomNumber = newRoomNumber;
    X = newX*32;
    Y = newY*32;
    TunnelLocation = newTunnelLocation;
}

int Room::getRoomNumber() {
    return RoomNumber;
}

int Room::getX() {
    return X;
}

int Room::getY(){
    return Y;
}

std::string Room::getTunnels() {
    return TunnelLocation;
}

std::string Room::defineTunnels(int RoomID, int rooms){
    return "i";
}
#endif //FTF1_ROOM_H
