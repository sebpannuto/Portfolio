
--Rooms must be a perfect square
seed = 4
room_size = 20

--World load options
world_size = 150

--DO NOT CHANGE ANYTHING UNDER HERE
--[[
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
 ]]
io.write("Building world")
world = {}
rooms = math.pow(seed, 2)
tunnels = (math.sqrt(rooms) * (math.sqrt(rooms) - 1)) * 2
locationX = {}
locationY = {}

for i=0, rooms do
    locationX[i] = 0
end

for i=0, rooms do
    locationY[i] = 0
end

for y=0, world_size do
    world[y] = {}
    for x=0, world_size do
        world[y][x] = 0
    end
end

--Tests Rooms to see if it is big enough to fit inside the world
io.write("\nTesting rooms")
if (room_size * math.sqrt(rooms)) + (math.sqrt(rooms) - 1) >= world_size then
    io.write("\nERROR NOT ENOUGH SPACE IN WORLD TO GENERATE MAP")
    io.write("\nPLEASE CHANGE NUMBER OF ROOMS OR WORLD SIZE")
else
    --Builds Rooms
    io.write("\nBuilding rooms\n")
    local room_states = {}
    local gap = 17
    local rowX = 1 + 1
    local rowY = 1 + 1

    local x = rowX
    local y = rowY

    local i = 0

    repeat
        room_states[i] = i + 1
        i = i + 1
    until i >= rooms

    --[[
        --randomizes rooms
        i = 0
        repeat
            local rand = math.random(0, rooms)
            local temp = room_states[i]
            room_states[i] = room_states[rand]
            room_states[rand] = temp
            i = i + 1
        until i >= seed
    --]]
    local counter = 0
    local rowCount = 0
    --actually builds rooms
    for j=0, rooms - 1 do
        print(j)
        local count_Y = 0
        local count_X = 0
        --builds individual rooms
        locationX[counter] = x
        locationY[counter] = y
        while count_Y < room_size do
            while count_X < room_size do
                world[y][x] = room_states[j]
                count_X = count_X + 1
                x = x + 1
            end
            y = y + 1
            x = rowX
            count_Y = count_Y + 1
            count_X = 0
        end
        rowCount = rowCount + 1
        rowX = rowX + room_size + gap
        --moves to next location
        if rowCount >= seed then
            rowX = 2
            rowY = rowY + room_size + gap
            rowCount = 0
        end
        y = rowY
        x = rowX
        counter = counter + 1
    end
    io.write("!Rooms built!")

    --Build Horizontal Tunnels
    local half = room_size / 2 + 1
    y = half
    x = room_size + 2
    local j = 0
    while j < math.sqrt(rooms) do
        i = 0
        while i < math.sqrt(rooms)-1 do
            for p=0, gap - 1 do
                world[y-1][x] = -1
                world[y][x] = -1
                world[y+1][x] = -1
                world[y+2][x] = -1
                x = x + 1
            end
            x = x + room_size
            i = i + 1
        end
        x = room_size + 2
        y = y + room_size + gap
        j = j + 1
    end

    --Build Vertical Tunnels
    local half = room_size / 2 + 1
    x = half
    y = room_size + 2
    local j = 0
    while j < math.sqrt(rooms) do
        i = 0
        while i < math.sqrt(rooms)-1 do
            for p=0, gap - 1 do
                world[y][x-1] = -1
                world[y][x] = -1
                world[y][x+1] = -1
                world[y][x+2] = -1
                y = y + 1
            end
            y = y + room_size
            i = i + 1
        end
        y = room_size + 2
        x = x + room_size + gap
        j = j + 1
    end

    --[[
    --prints out location
        for i=0, rooms do
            io.write("\n", locationX[i], " ")
            io.write(locationY[i])
        end
    --]]
    --prints out world
    io.write("\nBuilding tile map")
    local file = io.open("../Resources/Assets/config/Map.txt", "w")
    io.output(file)

    for y=0, world_size do
        for x=0, world_size do
            if x <= -1 or x >= world_size then
                io.write("0", world[y][x])
            else
                if world[y][x] > 0 then
                    io.write("R", world[y][x], " ")
                elseif world[y][x] == 0 then
                    io.write("0", world[y][x], " ")
                else
                    io.write("TT", " ")
                end

            end

        end
        io.write("\n")
    end
    io.close(file)

    print("\n!Tile Map complete!")
    print("!World built!")
end