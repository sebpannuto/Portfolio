//
// Created by Dreamcatcher on 10/23/2017.
//

#ifndef FTF1_TIMER_H
#define FTF1_TIMER_H

#include "SDL.h"
#include "SDL_ttf.h"

class Ttimer{
private:
    Uint32 hh,mm,ss, ms, pTime, cTime, changeInTime;
    void convertTime();
    bool paused = false;
    TTF_Font* font;
    SDL_Color color;

public:
    Uint32 getMSec();
    Uint32 getSec();
    Uint32 getMin();
    Uint32 getHrs();
    SDL_Texture* getTexture(SDL_Renderer* renderer);
    std::string getText();
    void updateTime();
    void pause(){
        paused = !paused;
    };

    Ttimer(){
        hh = mm = ss = ms = 0;
        cTime = SDL_GetTicks();

        if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
            std::cout << "Video Initialization Error" << SDL_GetError() << std::endl;
        TTF_Init();

        font = TTF_OpenFont("../Resources/Assets/fonts/OpenSans-Regular.ttf", 24);
        color = {255, 255, 255};
    }
};

void Ttimer::updateTime(){
    pTime = cTime;
    cTime = SDL_GetTicks();
    changeInTime = cTime - pTime;
    if(!paused){
        ms += changeInTime;
        convertTime();
    }
}

void Ttimer::convertTime(){
    if(ms / 1000 > 0){
        ss += ms / 1000;
        ms = ms % 1000;
    }
    if(ss >= 60){
        mm += ss / 60;
        ss = ss % 60;
    }
    if(mm >= 60) {
        hh += mm / 60;
        mm = mm % 60;
    }
}

Uint32 Ttimer::getMSec(){
    return ms;
}

Uint32 Ttimer::getSec(){
    return ss;
}

Uint32 Ttimer::getMin(){
    return mm;
}

Uint32 Ttimer::getHrs(){
    return hh;
}

std::string Ttimer::getText(){
    return std::to_string(this->getHrs()) + ":" + std::to_string(this->getMin()) + ":" +
          std::to_string(this->getSec()) + ":" + std::to_string(this->getMSec());

}

SDL_Texture* Ttimer::getTexture(SDL_Renderer* renderer){
    return SDL_CreateTextureFromSurface(renderer, TTF_RenderText_Solid(font, &this->getText()[0], color) );
}

#endif //FTF1_TIMER_H

