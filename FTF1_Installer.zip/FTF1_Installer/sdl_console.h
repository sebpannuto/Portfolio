//
// Created by mattr on 10/13/2017.
//

#ifndef FTF1_SDL_CONSOLE_H
#define FTF1_SDL_CONSOLE_H

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>

class Console{
    private:

    SDL_Window *window;
    SDL_Renderer *renderer;
    SDL_Texture *texture;

    TTF_Font *font;
    public:

    Console();
    ~Console();
    void print(const char *c);
};

Console::Console(){
    window=SDL_CreateWindow("console", 50,50,1000, 0, 0);
    renderer=SDL_GetRenderer(window);
    font;
}

Console::~Console() {
    SDL_DestroyTexture(texture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
}

void Console::print(const char *c) {
    SDL_SetWindowTitle(window, c);
}
#endif //FTF1_SDL_CONSOLE_H
