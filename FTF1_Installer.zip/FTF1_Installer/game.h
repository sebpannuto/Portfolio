//
// Created by mattr on 11/20/2017.
//

#ifndef FTF1_GAME_H_H
#define FTF1_GAME_H_H
#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <fstream>
#include <vector>
#include "entity.h"
#include "player.h"
#include "camera.h"
#include "enemy.h"
#include "tile.h"
#include "structure.h"
#include "map.h"
#include "Room.h"
#include "inventory.h"
#include "item.h"
#include "timer.h"
#include "Score.h"
#include "saveFileCreator.h"
#include "Score.h"

#define WIN_W 640 //1080
#define WIN_H 480 //810
#define fps 60





//void cap_framerate(Uint32 starting_tick) {
//    if ((1000 / fps) > SDL_GetTicks() - starting_tick) {
//        SDL_Delay(1000 / fps - (SDL_GetTicks() - starting_tick));
//    }
//}

class Game{
private:
    SDL_Window *window;
    SDL_Renderer* renderer;
    SDL_Rect lvl;
    SDL_Rect timer_rect={WIN_W-100,0, 100, 50 };
    Uint32 windowID;
    int room_num;



    std::vector<Enemy*> enemies;
    std::vector<Structure*> structures;

    Player* player;
    Map *map;
    std::vector<Room> rooms;
    Tile tile;
    Camera camera;
    Ttimer timer;
    Inventory *inventory;
    std::vector<Item*> items;
    std::vector<Structure*> doors;


    void init();
    void input(SDL_Event event);
    void animate();
    void update();
    bool collision();
    void render(SDL_Texture* overlay);
    void sliding();
    bool pause();
    void quit();



public:
    Game();
    void run();


};
Game::Game() {
    player=NULL;
    map=NULL;
    srand(time(NULL));
    out=std::ofstream("../debug.txt", std::ofstream::out);
    if(out.is_open()){
        out<<"file opened";
    }
}


void Game::init(){
    TTF_Init();


    window =SDL_CreateWindow("Face The Future!!!!!",SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIN_W, WIN_H,0);
    renderer = SDL_CreateRenderer(window,-1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

    windowID=SDL_GetWindowID(window);
    LOAD=new Loader(renderer);

    map=new Map();
    rooms=map->getRooms();
    tile=Tile(renderer);
    tile.createLayouts(rooms.size());
    lvl=tile.getRect();

    camera=Camera(WIN_W, WIN_H, lvl);
    player=new Player(lvl.x+lvl.w/2, lvl.y+lvl.h/2, renderer,"player");
    timer=Ttimer();


    for(int i=0;i<tile.getLayout(0).X.size();i++){
        enemies.push_back(new Enemy(tile.getLayout(0).X.at(i),
                                    tile.getLayout(0).Y.at(i),
                                    renderer,
                                    tile.getLayout(0).type.at(i)));
    }

    room_num=1;

    if(rooms[room_num-1].getTunnels().find_first_of('N')!=std::string::npos)
        structures.push_back(new Structure(lvl.x+lvl.w-16, lvl.y, renderer,"gate"));
    if(rooms[room_num-1].getTunnels().find_first_of('S')!=std::string::npos)
        structures.push_back(new Structure(lvl.x+lvl.w/2-16, lvl.y+lvl.h-32, renderer,"gate"));
    if(rooms[room_num-1].getTunnels().find_first_of('E')!=std::string::npos)
        structures.push_back(new Structure(lvl.x+lvl.w-32, lvl.y+lvl.h/2-16, renderer,"gate"));
    if(rooms[room_num-1].getTunnels().find_first_of('W')!=std::string::npos)
        structures.push_back(new Structure(lvl.x, lvl.y+lvl.h/2-16, renderer,"gate"));


    player->setLevelSize(lvl);
    for(int i=0; i<enemies.size(); i++){
        enemies[i]->setLevelSize(lvl);
    }
    for(int i=0; i<structures.size(); i++){
        structures[i]->setLevelSize(lvl);
    }
}

void Game::input(SDL_Event event) {
    player->processInput(event);
    for(int i=0; i<enemies.size();i++){
        enemies[i]->process_AI();
    }
}

void Game::animate(){
    player->animate();
    for(int i=0; i<enemies.size();i++){
        enemies[i]->animate();
    }
}

void Game::update() {
    //center camera around player
    camera.setPos(player->getRect());
    camera.update();        //must update first!!!!!!!

    player->update(camera.getRect().x, camera.getRect().y);
    for(int i=0; i<enemies.size();i++){
        enemies[i]->update(camera.getRect().x, camera.getRect().y);
    }
    for(int i=0; i<structures.size();i++){
        structures[i]->setDisplay(camera.getRect().x, camera.getRect().y);
    }

    for(int i=0; i<items.size(); i++)
        items[i]->update(camera.getRect().x, camera.getRect().y);

    for(int i=0; i<doors.size(); i++)
        doors[i]->update(camera.getRect().x, camera.getRect().y);
}

bool Game::collision() {
    bool goal=false;

    for(int i=0; i<enemies.size();i++){///player to enemy
        if(Entity::collision(*player, *enemies[i])){
            enemies.erase(enemies.begin()+i);
        }


        for(int j=0; j<enemies.size(); j++){///enemy to enemy
            if(i!=j)///remove for awesome bug
                Entity::collision(*enemies[i], *enemies[j]);
        }
    }

    for(int i=0; i<items.size(); i++){///player to item
        if(Entity::collision(*player, *items[i])){
            items.clear();
            inventory = new Inventory("player");
        }
    }

    for(int i=0; i<doors.size(); i++){///player to door
        if(Entity::collision(*player, *doors[i])){
            i;
        }
    }

    if(player->goal)
        goal=true;
    for(int i=0; i<structures.size(); i++) {
        if (Entity::collision(*player, *structures[i])) {
            sliding();
        }
    }
    return goal;
}

void Game::render(SDL_Texture* overlay) {

///reset renderer
    SDL_RenderClear(renderer);

    tile.render(camera);

    for(int i=0; i<doors.size(); i++)
        doors[i]->render();

    player->render();

    for(int i=0; i<enemies.size();i++){
        enemies[i]->render();
    }
    for(int i=0; i<structures.size();i++){
        structures[i]->render();
    }

    for(int i=0; i<items.size(); i++)
        items[i]->render();


    if(overlay){
        SDL_RenderCopy(renderer,overlay, NULL, NULL);
    }

    SDL_RenderCopy(renderer,timer.getTexture(renderer),NULL, &timer_rect );

    ///apply render changes
    SDL_RenderPresent(renderer);
}

void Game::quit(){
    delete player;
    delete map;
    delete inventory;
    tile.quit();

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
}

//////////////////////////
void Game::sliding(){
    char dir;
    SDL_Rect target;
    bool run=true;

    Uint32 ticks;
    SDL_Rect focus={camera.getRect().x+camera.getRect().w/2,
                    camera.getRect().y+camera.getRect().h/2,
                    1,1};


    player->setLevelSize({0,0,2000000000,2000000000});
    camera.setLevelSize({0,0,2000000000,2000000000});

    if(player->getRect().y < lvl.y + lvl.h/4) {///find which gate was hit
        dir='N';
        target={lvl.x,rooms[room_num-1-sqrt(rooms.size())].getY(),lvl.w ,lvl.h };//go back one row
        room_num-=sqrt(rooms.size());
    }
    else if(player->getRect().y > lvl.y +lvl.h - lvl.h/4){
        dir='S';
        target={lvl.x,rooms[room_num-1 +sqrt(rooms.size())].getY(),lvl.w ,lvl.h };//go forward one row
        room_num+=sqrt(rooms.size());
    }
    else if(player->getRect().x < lvl.x + lvl.w/4) {
        dir='W';
        target={rooms[room_num-1 -1].getX(),lvl.y,lvl.w ,lvl.h };//go backward one room number
        room_num-=1;
    }
    else if(player->getRect().x > lvl.x +lvl.w - lvl.w/4) {
        dir='E';
        target={rooms[room_num-1 +1].getX(),lvl.y,lvl.w ,lvl.h };//go forward one room number
        room_num+=1;
    }


    while(focus.x<target.x ||
          focus.x>target.x+target.w ||
          focus.y<target.y  ||
          focus.y>target.y+target.h){///while outside of target room


        ticks=SDL_GetTicks();

        if(dir=='N') focus.y-=5;
        else if(dir=='S') focus.y+=5;
        else if(dir=='W') focus.x-=5;
        else if(dir=='E') focus.x+=5;



        //center camera around player
        camera.setPos(focus);

        //force player to move
        player->slide(focus);

        player->animate();

        //apply and bind new positions
        camera.update();        //must update first!!!!!!!
        player->setDisplay(camera.getRect().x, camera.getRect().y);



        //render everything
        tile.render(camera);
        player->render();


        //apply render changes
        SDL_RenderPresent(renderer);

        //reset renderer
        SDL_RenderClear(renderer);

        cap_framerate(ticks);                                           //limit framerate
    }


    player->slide(false);



    lvl.x=target.x;
    lvl.y=target.y;

    player->setLevelSize(lvl);
    camera.setLevelSize(lvl);
    tile.setLevelSize(lvl);
    enemies.clear();
    structures.clear();

    for(int i=0;i<tile.getLayout(room_num-1).X.size();i++){          /// add enemies to new room
        enemies.push_back(new Enemy(tile.getLayout(room_num-1).X.at(i),
                                    tile.getLayout(room_num-1).Y.at(i),
                                    renderer,
                                    tile.getLayout(room_num-1).type.at(i)));

        enemies[i]->setLevelSize(lvl);
    }

    if(tile.getLayout(room_num-1).key) {
        items.push_back(new Item(lvl.x+lvl.w/2+50,lvl.y+lvl.h/2 ,renderer,"key"));
       items.back()->setLevelSize(lvl);
    }

    if(tile.getLayout(room_num-1).door) {
        doors.push_back(new Structure(lvl.x+lvl.w/2-50,lvl.y+lvl.h/2-50 ,renderer,"door"));
        doors.back()->setLevelSize(lvl);
        doors.back()->setSize(100, 100);
    }


    if(rooms[room_num-1].getTunnels().find_first_of('N')!=std::string::npos && dir!='S')        ///reset gates
        structures.push_back(new Structure(lvl.x+lvl.w/2-16, lvl.y, renderer,"gate"));
    if(rooms[room_num-1].getTunnels().find_first_of('S')!=std::string::npos && dir!='N')
        structures.push_back(new Structure(lvl.x+lvl.w/2-16, lvl.y+lvl.h-32, renderer,"gate"));
    if(rooms[room_num-1].getTunnels().find_first_of('E')!=std::string::npos && dir!='W')
        structures.push_back(new Structure(lvl.x+lvl.w-32, lvl.y+lvl.h/2-16, renderer,"gate"));
    if(rooms[room_num-1].getTunnels().find_first_of('W')!=std::string::npos && dir!='E')
        structures.push_back(new Structure(lvl.x, lvl.y+lvl.h/2-16, renderer,"gate"));
};

bool Game::pause(){
    bool run=true;
    SDL_Event event;
    Uint32 ticks;/// framerate
    Uint8 alpha = 150;
    SDL_Texture* overlay = LOAD->get_texture("pause_menu");

timer.pause();

    SDL_SetTextureBlendMode( overlay, SDL_BLENDMODE_BLEND );

    while(run) {
        ticks = SDL_GetTicks();

        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT)
                return false;
            else if (event.type == SDL_WINDOWEVENT && event.window.event == SDL_WINDOWEVENT_CLOSE) {
                if (event.window.windowID == windowID) {
                    return false;
                }
            }
            else if(event.type==SDL_KEYDOWN) {
                if (event.key.keysym.scancode == SDL_SCANCODE_RETURN)
                    run = false;
                if(event.key.keysym.scancode == SDL_SCANCODE_Q)
                    return false;

                if( event.key.keysym.scancode == SDL_SCANCODE_A )
                {
                  alpha-=5;
                }
            }
        }
        SDL_SetTextureAlphaMod(overlay, alpha);

        render(overlay);


        cap_framerate(ticks);  ///limit framerate
        timer.updateTime();
    }

    timer.pause(); ///unpause

    return true;
}

////////////////////////////
void Game::run() {
    DebugConsole posCon(0,50);
    DebugConsole posCon2(0,250);

    init();


    bool run=true;
    SDL_Event event;
    Uint32 ticks;/// framerate

    while(run) {
        ticks=SDL_GetTicks();

        while( SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT)
                run = false;
            else if(event.type == SDL_WINDOWEVENT && event.window.event==SDL_WINDOWEVENT_CLOSE)
            {
                if(event.window.windowID==windowID) {
                    run = false;
                    posCon.~DebugConsole();
                    posCon2.~DebugConsole();
                }
                if(event.window.windowID==posCon.getID() || event.window.windowID==posCon2.getID()){
                    posCon.~DebugConsole();
                    posCon2.~DebugConsole();
                }
            }
            if(event.type==SDL_KEYDOWN) {
                if(event.key.keysym.scancode==SDL_SCANCODE_ESCAPE)
                    run=pause();

            }
        }


        input(event); ///includes AI

        animate();

        update();   ///sets camera

        if(collision()) ///triggers sliding
            run=false;

        render(NULL);


        posCon.print(Debug_Output);
        posCon2.print(Debug_Output2);
        Debug_Output2="";

        cap_framerate(ticks);  ///limit framerate
        timer.updateTime();
    }

    run=true;
    timer.pause();

    while(run && player->goal){
        ticks=SDL_GetTicks();

        while( SDL_PollEvent(&event)) {
            if(event.type==SDL_KEYDOWN) {
                    run=false;
            }

            else if(event.type == SDL_WINDOWEVENT && event.window.event==SDL_WINDOWEVENT_CLOSE) {
                if (event.window.windowID == windowID) {
                    run = false;
                    posCon.~DebugConsole();
                    posCon2.~DebugConsole();
                }
            }
        }

        SDL_RenderCopy(renderer, LOAD->get_texture("congratulations"), NULL, NULL);
        SDL_RenderPresent(renderer);
        cap_framerate(ticks);
    }

    if(player->goal) {

        SaveScore CSV;
        Score score;

        std::string time = std::to_string(timer.getHrs()) + "h : " + std::to_string(timer.getMin()) + "m : " +
                           std::to_string(timer.getSec()) + "s : " + std::to_string(timer.getMSec());
        CSV.save_score(score.playerInputConsole(), time);
    }


    quit();
}

#endif //FTF1_GAME_H_H
