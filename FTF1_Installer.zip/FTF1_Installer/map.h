//
// Created by mattr on 11/2/2017.
//

#ifndef FTF1_MAP_H
#define FTF1_MAP_H


#include <cstdlib>
#include <string>
#include <iostream>
#include <lua.hpp>
#include <vector>
#include <fstream>

#include "map.h"
#include "SDL.h"
#include "Room.h"

class Map{
public:
    Map();
    int getWorld_Size();
    std::vector<Room> getRooms();
    int getRoom_Size();
    int getTunnels();

private:
    int world_size;
    int rooms;
    int room_size;
    int tunnels;
    std::vector<Room> RoomsInWorld;
};



//Map::Map() {
//    std::ofstream out=std::ofstream("../debug.txt", std::ofstream::out);
//
//    lua_State *L = luaL_newstate();
//    luaL_openlibs(L);
//
//    if(luaL_dofile(L, "../world_config.lua")) {
//        SDL_Window *win = SDL_CreateWindow("lua_config did not load", 100, 100, 300, 10, 0);
//        SDL_Delay(4000);
//        SDL_DestroyWindow(win);
//    }
//
//    lua_getglobal(L, "world_size");
//    lua_getglobal(L, "rooms");
//    lua_getglobal(L, "room_size");
//    lua_getglobal(L, "tunnels");
//
//    world_size = (int)lua_tonumber(L, -4);
//    rooms = (int)lua_tonumber(L, -3);
//    room_size = (int)lua_tonumber(L, -2);
//    tunnels = (int)lua_tonumber(L, -1);
//
//
//
/////gets location of rooms
//    int stackSize = lua_gettop(L);
//    lua_pop(L, stackSize);
//
//    int x = 0;
//    int locationX[rooms];
//    lua_getglobal(L, "locationX");
//    lua_pushnil(L);
//    while(lua_next(L, -2)) {
//        locationX[x] = (int)lua_tonumber(L, -1);
//        lua_pop(L, 1);
//        x++;
//    }
//
//    stackSize = lua_gettop(L);
//    lua_pop(L, stackSize);
//
//    x = 0;
//    int locationY[rooms];
//    lua_getglobal(L, "locationY");
//    lua_pushnil(L);
//    while(lua_next(L, -2)) {
//        locationY[x] = (int)lua_tonumber(L, -1);
//        lua_pop(L, 1);
//        x++;
//    }
//
//    int location[2][rooms];
//    location[0][0] = 2;
//    location[1][0] = 2;
//
//    int i;
//    int j;
//    for (i = 1; i < rooms; i++){
//        location[0][i] = locationY[i-1];
//        location[1][i] = locationX[i-1];
//    }
//
//    std::string DTunnels[] = {"SE", "SEW", "SW", "NSE", "NSEW", "NSW", "NE", "NEW", "NW"};
//    ///Creates an array of rooms
//   // Room RoomsInWorld[rooms];
//    for(i=0; i < rooms; i++){
//        Room R = Room(i+1, location[1][i], location[0][i], DTunnels[i]);
//        RoomsInWorld.push_back(R);
//    }
//
//}

Map::Map() {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    luaL_dofile(L, "../Resources/Assets/config/world_config.lua");

    lua_getglobal(L, "world_size");
    lua_getglobal(L, "rooms");
    lua_getglobal(L, "room_size");
    lua_getglobal(L, "tunnels");

    world_size = (int)lua_tonumber(L, -4);
    rooms = (int)lua_tonumber(L, -3);
    room_size = (int)lua_tonumber(L, -2);
    tunnels = (int)lua_tonumber(L, -1);

//gets location of rooms
    int stackSize = lua_gettop(L);
    lua_pop(L, stackSize);

    int x = 0;
    int locationX[rooms];
    lua_getglobal(L, "locationX");
    lua_pushnil(L);
    while(lua_next(L, -2)) {
        locationX[x] = (int)lua_tonumber(L, -1);
        lua_pop(L, 1);
        x++;
    }

    stackSize = lua_gettop(L);
    lua_pop(L, stackSize);

    x = 0;
    int locationY[rooms];
    lua_getglobal(L, "locationY");
    lua_pushnil(L);
    while(lua_next(L, -2)) {
        locationY[x] = (int)lua_tonumber(L, -1);
        lua_pop(L, 1);
        x++;
    }

    int location[2][rooms];
    location[0][0] = 2;
    location[1][0] = 2;

    int i;
    int j;
    for (i = 1; i < rooms; i++){
        location[0][i] = locationY[i-1];
        location[1][i] = locationX[i-1];
    }

    std::string DTunnels[rooms];
    int left = sqrt(rooms);
    int right = sqrt(rooms) - 1;
//    for (i = 0; i < rooms; i++){
//        if (i > 0 && i < (sqrt(rooms)-1)) {
//            DTunnels[i] = "SEW";
//        }
//        else if(i < rooms-sqrt(rooms) + 1) {
//            if (i == left) {
//                DTunnels[i] = "NSE";
//                left = left + i;
//            }
//            else if ( i == right) {
//                DTunnels[i] = "NSW";
//                right = sqrt(rooms) + i;
//            }
//            else{
//                DTunnels[i] = "NSEW";
//            }
//        }
//        else if (i > abs(rooms-sqrt(rooms)) && i < rooms-1){
//            DTunnels[i] = "NEW";
//        }
//    }
//    DTunnels[0] = "SE";
//    DTunnels[(int)sqrt(rooms)-1] = "SW";
//    DTunnels[(int)(rooms-sqrt(rooms))] = "NE";
//    DTunnels[rooms-1] = "NW";
    ///////mathews direction tunnels
    for(int i=sqrt(rooms); i<rooms; i++)
        DTunnels[i]+="N";
    for(int i=0; i<rooms-sqrt(rooms); i++)
        DTunnels[i]+="S";
    for(int i=0; i<rooms; i++)
        if( i%(int)(sqrt(rooms)) !=sqrt(rooms)-1 )
            DTunnels[i]+="E";
    for(int i=0; i<rooms; i++)
        if( i%(int)(sqrt(rooms)) !=0)
            DTunnels[i]+="W";




    //Creates an array of rooms
    //Room RoomsInWorld[rooms];
    for(i=0; i < rooms; i++){
        Room R = Room(i+1, location[1][i], location[0][i], DTunnels[i]);
        RoomsInWorld.push_back(R);
    }

    //prints out everything
    for(i = 0; i < rooms; i++){
        std::cout << "Room " << RoomsInWorld[i].getRoomNumber() << "; (" << RoomsInWorld[i].getX() <<
                  ", " << RoomsInWorld[i].getY() << "); " << RoomsInWorld[i].getTunnels() << std::endl;
    }

    std::cout << world_size << std::endl;
    std::cout << rooms << std::endl;
    std::cout << room_size << std::endl;
    std::cout << tunnels << std::endl;

}

int Map::getWorld_Size() {
    return world_size;
}

std::vector<Room> Map::getRooms() {
    return RoomsInWorld;
}

int Map::getRoom_Size() {
    return room_size;
}

int Map::getTunnels() {
    return tunnels;
}
#endif //FTF1_MAP_H
