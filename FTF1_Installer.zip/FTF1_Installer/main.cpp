#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include "game.h"

void help_menu(){
    bool run=true;
    SDL_Event event;

    while(run){
        while( SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT)
                run = false;
            if(event.type==SDL_KEYDOWN) {
                run=false;

            }
        }
    }
}

int   main( int argc, char * args[] ){


    Game FTF1;



        //Sets the window size
        int win_height = 640;
        int win_width = 480;

        //Sets the ratios for the buttons and cloud selector
        //This ensures that if the window is resized, the buttons and
        //Selector get resized properly
        const float BUTTON_WIDTH_RATIO = .154286;
        const float BUTTON_HEIGHT_RATIO = .033333;
        const float SELECTOR_WIDTH_RATIO = .05357;
        const float SELECTOR_HEIGHT_RATIO = .075;


        //Using the above ratios, sets the sizes of the buttons/selector
        int button_width = (int)(win_width*BUTTON_WIDTH_RATIO);
        int button_height = (int)(win_height*BUTTON_HEIGHT_RATIO);
        int selector_width = (int)(win_width*SELECTOR_WIDTH_RATIO);
        int selector_height = (int)(win_height*SELECTOR_HEIGHT_RATIO);

        //Creates the textures and the renderer
        SDL_Window *window;
        SDL_Renderer *renderer;
        SDL_Texture *BG_Image;
        SDL_Texture *selector_texture;
        SDL_Texture *new_game_texture;
        SDL_Texture *continue_game_texture;
        SDL_Texture *view_scores_texture;
        SDL_Texture *quit_game_texture;
        SDL_Texture *help_menu1;
        SDL_Texture *help_menu2;
        SDL_Surface *temp_surface;


        //Creates the rects for each menu selection, and the selector
        //selector_pos refers to the menu selection number, 1-4.
        //selecter_pos_modifier and selecter_pos_modifier_spacing tell the selector how far up and down to move
        //when a player presses up or down

        int selector_pos = 1;
        float selector_pos_modifier = 0;
        float selector_pos_modifier_spacing = .065;
        SDL_Rect selector = {(int)(win_width*.53), (int)(win_height*(.485+selector_pos_modifier)), selector_width, selector_height};
        SDL_Rect new_game = {(int)(win_width*.6), (int)(win_height*.5), button_width, button_height};
        SDL_Rect continue_game = {(int)(win_width*.6), (int)(win_height*.565), button_width, button_height};
        SDL_Rect view_scores = {(int)(win_width*.6), (int)(win_height*.630), button_width, button_height};
        SDL_Rect quit_game = {(int)(win_width*.6), (int)(win_height*.695), button_width, button_height};

        //Event handling, run determines if the program is running or should quit
        bool run = true;
        SDL_Event event;


        //initialize SDL libraries
        SDL_Init(SDL_INIT_VIDEO || SDL_INIT_AUDIO);
        IMG_Init(IMG_INIT_PNG || IMG_INIT_JPG);


        //sets the background image
        window = SDL_CreateWindow("FTF1", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, win_height, win_width, SDL_WINDOW_SHOWN);
        renderer = SDL_CreateRenderer(window, -1, 0);



        //BEGIN create textures from image assets
        temp_surface = IMG_Load("../Resources/Assets/menu/background.png");
        BG_Image = SDL_CreateTextureFromSurface(renderer, temp_surface);

        temp_surface = IMG_Load("../Resources/Assets/menu/selector.png");
        selector_texture = SDL_CreateTextureFromSurface(renderer, temp_surface);

        temp_surface = IMG_Load("../Resources/Assets/menu/new_game.png");
        new_game_texture = SDL_CreateTextureFromSurface(renderer, temp_surface);

        temp_surface = IMG_Load("../Resources/Assets/menu/continue_game.png");
        continue_game_texture = SDL_CreateTextureFromSurface(renderer, temp_surface);

        temp_surface = IMG_Load("../Resources/Assets/menu/help_button.png");
        view_scores_texture = SDL_CreateTextureFromSurface(renderer, temp_surface);

        temp_surface = IMG_Load("../Resources/Assets/menu/quit_button.png");
        quit_game_texture = SDL_CreateTextureFromSurface(renderer, temp_surface);

        temp_surface = IMG_Load("../Resources/Assets/menu/help_menu1.png");
        help_menu1 = SDL_CreateTextureFromSurface(renderer, temp_surface);

       temp_surface = IMG_Load("../Resources/Assets/menu/help_menu2.bin");
        help_menu2 = SDL_CreateTextureFromSurface(renderer, temp_surface);


        SDL_FreeSurface(temp_surface);
        //END texture creation


        //Main game loop. While run=true, listen for SDL Events
        while (run){

            while(SDL_PollEvent(&event)){

                //if a key is pressed
                if(event.type==SDL_KEYDOWN){

                    //if that key is up, move selector up one position
                    if(event.key.keysym.sym==SDLK_UP){

                        //if the selector is at the top, wrap around to bottom
                        if (selector_pos == 1){
                            selector_pos = 4;
                        }
                        else {
                            selector_pos--;
                        }
                        selector_pos_modifier = (selector_pos-1)*selector_pos_modifier_spacing;
                    }

                    //if the key is down, move selector down one position
                    if(event.key.keysym.scancode==SDL_SCANCODE_DOWN){

                        //if the selector is at the bottom, wrap around to top
                        if (selector_pos == 4){
                            selector_pos = 1;
                        }
                        else{
                            selector_pos++;
                        }
                        selector_pos_modifier = (selector_pos-1)*selector_pos_modifier_spacing;
                    }

                    //if player hits enter/return, do events based on what selector has selected
                    if(event.key.keysym.sym==SDLK_KP_ENTER || event.key.keysym.sym==SDLK_RETURN ){
                        switch(selector_pos){
                            case 1: FTF1.run(); break;///run main game function
                            case 2: break;///score view
                            case 3: {
                                bool helping = true;
                                int menu_num = 0;///help_menu

                                while (helping) {
                                    while (SDL_PollEvent(&event)) {
                                        if (event.type == SDL_QUIT)
                                            helping = run = false;
                                        if (event.type == SDL_KEYDOWN) {
                                            menu_num++;
                                        }
                                    }
                                    if (menu_num == 0)
                                        SDL_RenderCopy(renderer, help_menu1, NULL, NULL);
                                    else if (menu_num == 1)
                                        SDL_RenderCopy(renderer, help_menu2, NULL, NULL);
                                    else
                                        helping = false;

                                    SDL_RenderPresent(renderer);

                                }
                                break;///help
                            }

                            case 4: run=false; break;
                            default: break;

                        }
                    }
                }

                //if the event is quit, set run to false, thus quitting the game
                if(event.type==SDL_QUIT){
                    run = false;
                }
            }

            //places selector based on modifier, changed above.
            //update the position of selector if the position changes, using the modifier
            selector.y=(int)(win_height*(.485+selector_pos_modifier));


            //render all of the textures
            SDL_RenderCopy(renderer, BG_Image, NULL, NULL);
            SDL_RenderCopy(renderer, new_game_texture, NULL, &new_game);
            SDL_RenderCopy(renderer, continue_game_texture, NULL, &continue_game);
            SDL_RenderCopy(renderer, view_scores_texture, NULL, &view_scores);
            SDL_RenderCopy(renderer, quit_game_texture, NULL, &quit_game);
            SDL_RenderCopy(renderer, selector_texture, NULL, &selector);
            SDL_RenderPresent(renderer);
        }



    SDL_DestroyTexture(BG_Image);
    SDL_DestroyTexture(selector_texture);
    SDL_DestroyTexture(new_game_texture);
    SDL_DestroyTexture(continue_game_texture);
    SDL_DestroyTexture(view_scores_texture);
    SDL_DestroyTexture(quit_game_texture);

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

        IMG_Quit();
        SDL_Quit();
}
//to do: pause with esc, quit game if "Q" pressed while paused


