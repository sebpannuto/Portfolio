//
// Created by ditenado on 12/5/17.
//

#ifndef FTF1_ITEM_H
#define FTF1_ITEM_H

#include <SDL.h>
#include "entity.h"

class Item : public Entity{
private:
    bool touchable(){return true;};
    void collision(Entity &e){};

public:
    Item(){};
    Item(int x, int y, SDL_Renderer *rend, std::string type):Entity(x,y,rend,type){
        Debug_Output+=std::to_string(rect.x)+" "+std::to_string(rect.y);
    };
};

#endif //FTF1_ITEM_H
