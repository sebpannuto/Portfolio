//
// Created by mattr on 11/7/2017.
//

#ifndef FTF1_STRUCTURE_H
#define FTF1_STRUCTURE_H

#include <SDL.h>
#include "entity.h"

class Structure : public Entity
{
    private:
    bool touchable(){return true;};
    void collision(Entity &e){};

    public:
    Structure(){};
    Structure(int x, int y, SDL_Renderer *rend, std::string type):Entity(x,y,rend,type){};
    void setSize(int w, int h){rect.w=w; rect.h=h; disp_rect.w=w; disp_rect.h=h;}
};



#endif //FTF1_STRUCTURE_H
