#include <cstdlib>
#include "Room.h"

Room::Room(){}

Room::Room(int newRoomNumber, int newX, int newY, std::string newTunnelLocation){
    RoomNumber = newRoomNumber;
    X = newX;
    Y = newY;
    TunnelLocation = newTunnelLocation;
}

int Room::getRoomNumber() {
    return RoomNumber;
}

int Room::getX() {
    return X;
}

int Room::getY(){
    return Y;
}

std::string Room::getTunnels() {
    return TunnelLocation;
}

std::string Room::defineTunnels(int RoomID, int rooms){
    return "i";
}