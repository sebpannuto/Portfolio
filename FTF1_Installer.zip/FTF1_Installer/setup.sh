#!/bin/bash

#cd ~
apt-get install cmake liblua5.3-dev libsdl2-ttf-dev libsdl2-dev libsdl2-image-dev
cmake -DCMAKE_BUILD_TYPE=Debug -G "Unix Makefiles" ./
cmake --build ./ --target FTF1 -- -j 2
mv FTF1 ~/.FTF1
echo '#!/bin/bash' > /usr/bin/FTF1
echo 'cd ~/.FTF1/bin' >> /usr/bin/FTF1
echo './FTF1' >> /usr/bin/FTF1
chmod +x /usr/bin/FTF1


