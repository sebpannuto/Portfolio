//
// Created by mattr on 10/16/2017.
//

#include <SDL.h>
#include <SDL_image.h>
#include <fstream>
#include <iostream>
#include "entity.h"
#include "sdl_console.h"
#include "debugConsole.h"


#define MAP_SIZE_W 151   /// 102 / 24 /48
#define MAP_SIZE_H 151   ///

#ifndef FTF1_TILE_H
#define FTF1_TILE_H



class Tile{
    private:
    SDL_Renderer *renderer;
    SDL_Texture *texture;
    SDL_Rect tile;
    SDL_Rect room;
    std::string map[MAP_SIZE_H][MAP_SIZE_W];


    std::string types[3]={"slime", "ghost", "red_slime"};
    struct layout{
        std::vector<int> X;
        std::vector<int> Y;
        std::vector<std::string> type;

        bool key=false;
        bool door=false;
    };

    std::vector<layout*> layouts;


    public:

    Tile(){};
    Tile( SDL_Renderer *rend);
    void quit(){SDL_DestroyTexture(texture);layouts.clear();};
    void loadMap();
    void createLayouts(int num_of_rooms);
    layout getLayout(int i){return *layouts[i];};
    void render(Camera c);
    SDL_Rect getRect();



    void setLevelSize(SDL_Rect level);

};

/*
 * Tile::Tile(SDL_Renderer *rend)
 *
 * loads a tile map from a text file
 *
 * parameters:
 *     SDL_Renderer rend:  main window renderer
 */

Tile::Tile(SDL_Renderer *rend){

    room={0,0,0,0};
    renderer=rend;
    loadMap(); //retrieve map from file

    int height=0, width=0;
    bool room_found=false;

    SDL_Surface *tile_map=NULL;


    tile={0,0,32, 32}; //rect for the tiles
    SDL_Rect temp;

    //tile map only works if initialized to a window
    SDL_Window* win=SDL_CreateWindow("tile_map",100, 100, MAP_SIZE_W*tile.w, MAP_SIZE_H*tile.h, SDL_WINDOW_HIDDEN);
    tile_map=SDL_GetWindowSurface(win);


    for(int i = 0; i < MAP_SIZE_H; i++)
    {
        for (int j = 0; j < MAP_SIZE_W; j++ )
        {
            if(map[i][j]=="00"){
                temp=tile;
                SDL_BlitSurface(LOAD->get_surface("crystal_floor0"),NULL, tile_map, &tile);
                tile=temp;
            }

            if(map[i][j]=="TT"){
                temp=tile;
                SDL_BlitSurface(LOAD->get_surface("mesh_floor1"),NULL, tile_map, &tile);
                tile=temp;
            }

            if(map[i][j][0]=='R'){
                room_found=true;
                temp=tile;
                SDL_BlitSurface(LOAD->get_surface("dirt_floor1"),NULL, tile_map, &tile);
                tile=temp;
            }

           tile.x+=tile.w;

            if(!room_found)
                room.x+=tile.w;
        }

        if(!room_found){
            room.x=0;
            room.y+=tile.h;
        }
        tile.x=0;
        tile.y+=tile.h;
    }


    width=20;   ///
    height=20;  ///


    texture=SDL_CreateTextureFromSurface(renderer, tile_map); //create main texture
    SDL_FreeSurface(tile_map);
    SDL_DestroyWindow(win);


    room.w=width*tile.w;
    room.h=height*tile.h;

    room.x=64;
    room.y=64;


}

/*
 * void Tile::loadMap()
 *
 * loads the text file map into the map array
 */

void Tile::loadMap() {
    std::ifstream file("../Resources/Assets/config/Map.txt");         ///

    if(file){
        for(int i = 0; i < MAP_SIZE_H; i++)
        {
            for (int j = 0; j < MAP_SIZE_W; j++ )
            {
                file >> map[i][j];
            }
        }
    }
}


void Tile::createLayouts(int num_of_rooms){
    int enemy_num;
    int key_spawn=0;
    int door_spawn;

    /*
     * push back layouts for the key and the goal first
     */

    for(int i=0; i<num_of_rooms;i++){

        enemy_num=rand()%9+5;
        layouts.push_back(new layout());

        for(int j=0; j<enemy_num; j++){
            layouts[i]->X.push_back(room.x+rand()%room.w);
            layouts[i]->Y.push_back(room.y+rand()%room.h);
            layouts[i]->type.push_back(types[rand()%3]);
        }
    }
    while(key_spawn==0)
        key_spawn=rand()%layouts.size();

    layouts[key_spawn]->key=true; //activate one key

    door_spawn=rand()%layouts.size();
    while(key_spawn==door_spawn || door_spawn==0)
        door_spawn=rand()%layouts.size();

    layouts[door_spawn]->door=true;
}



//renders tile background
void Tile::render(Camera c) {
    SDL_RenderCopy(renderer, texture, c.getRectADDR(), NULL);
}


//returns rect for the room
SDL_Rect Tile::getRect() {
    return room;
}

void Tile::setLevelSize(SDL_Rect level) {
    room=level;

    for(int i=0; i<layouts.size(); i++){//for every room

        for(int j=0; j<layouts[i]->X.size(); j++){
            layouts[i]->X[j]=room.x+rand()%room.w;
            layouts[i]->Y[j]=room.y+rand()%room.h;
        }
    }
}





#endif //FTF1_TILE_H
