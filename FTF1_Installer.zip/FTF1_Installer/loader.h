//
// Created by mattr on 10/25/2017.
//

#ifndef FTF1_LOADER_H
#define FTF1_LOADER_H

#include <map>
#include <iostream>
#include <SDL.h>
#include <SDL_image.h>

class Loader{
    private:
    std::map<std::string, SDL_Texture*> Textures;
    std::map<std::string, SDL_Surface*> Surfaces;


    public:
    Loader(SDL_Renderer* rend);
    SDL_Texture* get_texture(std::string s);
    SDL_Surface* get_surface(std::string s);

    ~Loader(){
        for(std::map<std::string, SDL_Texture*>::iterator it=Textures.begin(); it!=Textures.end(); it++ )
            SDL_DestroyTexture(it->second);
        for(auto it=Surfaces.begin(); it!=Surfaces.end(); it++ )
            SDL_FreeSurface(it->second);
    };
};

Loader::Loader(SDL_Renderer *rend) {
    SDL_Surface *image;
    SDL_Texture *texture;
    SDL_Renderer *renderer=rend;

    image=IMG_Load("../Resources/Assets/sptites/ladonia_XP_sprite.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("ladonia sprite did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    texture=SDL_CreateTextureFromSurface(renderer, image);
    Textures["player"]=texture;


    image=IMG_Load("../Resources/Assets/sptites/slime_sprite.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("slime sprite did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    texture=SDL_CreateTextureFromSurface(renderer, image);
    Textures["slime"]=texture;


    image=IMG_Load("../Resources/Assets/sptites/slime_sprite_ghost.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("ghost sprite did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    texture=SDL_CreateTextureFromSurface(renderer, image);
    Textures["ghost"]=texture;

    image=IMG_Load("../Resources/Assets/sptites/slime_sprite_red.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("red slime sprite did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    texture=SDL_CreateTextureFromSurface(renderer, image);
    Textures["red_slime"]=texture;

    image=IMG_Load("../Resources/Assets/sptites/dngn_exit_abyss.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("dungeon gate did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    texture=SDL_CreateTextureFromSurface(renderer, image);
    Textures["gate"]=texture;

    image=IMG_Load("../Resources/Assets/sptites/Key.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("key did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    texture=SDL_CreateTextureFromSurface(renderer, image);
    Textures["key"]=texture;

    image=IMG_Load("../Resources/Assets/sptites/door.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("door did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    texture=SDL_CreateTextureFromSurface(renderer, image);
    Textures["door"]=texture;

    image=IMG_Load("../Resources/Assets/menu/Congratulations.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("congrats did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    texture=SDL_CreateTextureFromSurface(renderer, image);
    Textures["congratulations"]=texture;

    ////////////////////////////////////////////////////////////////
    ///   tile loading
    ///////////////////////////////////////////////////////////////




    image=IMG_Load("../Resources/Assets/tiles/dirt1.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("dirt1 did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    Surfaces["dirt_floor1"]=image;


    image=IMG_Load("../Resources/Assets/tiles/crystal_floor0.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("crystal_floor0 did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    Surfaces["crystal_floor0"]=image;


    image=IMG_Load("../Resources/Assets/tiles/mesh1.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("mesh1 did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    Surfaces["mesh_floor1"]=image;


    image=IMG_Load("../Resources/Assets/tiles/cobble_blood1.png");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("cobble_blood1 did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    Surfaces["cobble_floor2"]=image;


    image=IMG_Load("../Resources/Assets/menu/pause_menu.bin");
    if(!image) {
        std::cout<<("IMG_Load: %s\n", IMG_GetError());
        SDL_Window* win=SDL_CreateWindow("pause_menu did not load",100, 100, 300, 10, 0 );
        SDL_Delay(4000);
        SDL_DestroyWindow(win);
    }
    texture=SDL_CreateTextureFromSurface(renderer, image);
    Textures["pause_menu"]=texture;

    SDL_FreeSurface(image);
}

SDL_Texture* Loader::get_texture(std::string s) {
    if(Textures.count(s))
        return Textures[s];
    else
        return NULL;
}

SDL_Surface* Loader::get_surface(std::string s){
    if(Surfaces.count(s))
        return Surfaces[s];
    else
        return NULL;
}
static Loader* LOAD;

#endif //FTF1_LOADER_H
