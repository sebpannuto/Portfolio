
//
// Created by ditenado on 12/5/17.
//

#ifndef saveFileCreator
#define saveFileCreator



#include <fstream>

#include <string>


class SaveScore{
    private:
    std::ofstream out;

    public:
    SaveScore(){ out=std::ofstream("../Resources/Assets/config/scoreSaveFile", std::fstream::app);}

    void save_score(std::string name, const std::string& score)
    {
        out<<name+","+score+"\n";
    }
};

#endif