//
// Created by mattr on 10/12/2017.
//

#ifndef FTF1_CHARACTER_H
#define FTF1_CHARACTER_H

#include <SDL.h>
#include "entity.h"

class Character : public Entity{

    protected:

    int step_dis;
    bool hit;
    bool mov;
    std::string dir;


    public:
    Character(){};
    Character(int x, int y, SDL_Renderer *rend, std::string type) : Entity(x,y,rend,type){};

    void update(int camera_x, int camera_y);
    void clear_dir();

    virtual void animate()=0;
    virtual bool touchable()=0;
    virtual void collision(Entity &e){};
};

/*
 * void Character::update(int camera_x, int camera_y)
 *
 * applies the change in location based on direction
 * confines character to the level
 * centers disp rect in the camera
 *
 * parameters:
 *      int camera_x: x coordinate of camera rect
 *      int camera_y: y coordinate of camera rect
 */
void Character::update(int camera_x, int camera_y) {

    if(mov) {
        if (dir[0] == 'L') {
            rect.x -= step_dis;
        }
        if (dir[0] == 'R') {
            rect.x += step_dis;
        }
        if (dir[1] == 'U') {
            rect.y -= step_dis;
        }
        if (dir[1] == 'D') {
            rect.y += step_dis;
        }
    }

    bind_to_lvl();

    setDisplay(camera_x, camera_y);
}

/*
 * void Character::clear_dir()
 *
 * resets direction to prevent false carryover
 *
 * parameters: none
 */
void Character::clear_dir() {
    dir[0]=' ';
    dir[1]=' ';
}
#endif //FTF1_CHARACTER_H
