/*
 * author: Matthew McCall
 * Class: player-   creates the main avatar the user will operate
 *                  handles inputs from the keyboard
 *                  loads sprite sheet and animates the sprite
 */
#ifndef SDL_TEST_PLAYER_H
#define SDL_TEST_PLAYER_H

#include <string>
#include <iostream>
#include <vector>
#include <SDL.h>
#include <SDL_image.h>
#include <sstream>
#include "character.h"
#include "sdl_console.h"//broken "pseudo console"
#include "debugConsole.h"


class Player : public Character{
    private:
    bool touchable();
    void collision(Entity &e);


    int invincible_time;
    const Uint8* keystate;
    bool sliding;
    bool centered=false;
    bool has_key;


    public:
    bool goal;

    //Player()= default;
    Player(int x, int y, SDL_Renderer *rend, std::string type);
    void processInput(SDL_Event e);
    void animate();
    void render();
    void slide(SDL_Rect focus);
    void slide(bool s);

    ~Player(){SDL_DestroyTexture;};
};


/*
 * Player::Player(int x, int y, SDL_Renderer *rend, char* path) : Character(x,y,rend,path)
 *
 * receives and sets location and of player on world, the renderer for the player and the takes the path
 * for the player sprite sheet. sends these parameters to the character constructor
 *
 * instantiates:
 *      disp_rect
 *      keystates:          boolean array of keyboard states
 *      sprite:             rect getting the frame from the sprite sheet
 *      mov:                whether or not player is moving
 *      hit:                player hit or not
 *      invincible_time:    count down timer for player flashing and invincible
 *      dir:                2 char string for direction of player movement dir[0]=L/R, dir[1]=U/D
 *
 * hardcoded:
 *      num_of_frames:   the number of frames on the sprite sheet
 *      num_of_dir:      the number of directions on the sprite sheet
 *
 * parameters:
 *  int x:                   x coordinate of player location
 *  int y:                   y coordinate of player location
 *  SDL_Renderer *rend:     main window renderer
 *  char* path:             path of the sprite sheet
 */

Player::Player(int x, int y, SDL_Renderer *rend, std::string type) : Character(x,y,rend,type){
    num_of_dir=4;
    num_of_frames=4;

    SDL_QueryTexture(texture, NULL, NULL, &sheet_w, &sheet_h);

    rect.w= sheet_w/num_of_frames;
    rect.h= sheet_h/num_of_dir;                                              //use pixels dimensions of sprite

    disp_rect=rect;


    sprite={0,0,sheet_w/num_of_frames, sheet_h/num_of_dir};

    keystate=SDL_GetKeyboardState(NULL);

    mov=false;
    step_dis=5;
    hit=false;
    invincible_time=0;
    dir=" D";
    sliding=false;
    goal=false;

}




/*
 * bool Player::touchable()
 *
 * returns whether the player is able to interact or not
 */
bool Player::touchable(){
    return !invincible_time;
}


/*
 * void Player::collision(Entity &e)
 *
 * decides effects for collision with other entities
 *
 * parameters:
 *      Entity &e: entity player collided with
 */
void Player::collision(Entity &e) {
    if(e.getType()=="slime" &&invincible_time==0)
        hit=true;
    if(e.getType()=="door" && has_key)
        goal=true;

    if(e.getType()=="gate"){
        sliding=true;
    }

    if(e.getType()=="key")
        has_key=true;
}

/*
 * void Player::processInput(SDL_Event e)
 *
 * collects input from the user using events and the keystate array
 * sets player directions with WSAD
 *
 * parameters:
 *      SDl_Event e: the event to be processed.
 *
 */
void Player::processInput(SDL_Event e){


    if(invincible_time==0) sliding=false;
    if(sliding){
//        if(rect.x<lvl.x+lvl.w/2) dir="R";
//        if(rect.x>lvl.x+lvl.w/2+100) dir="L";
//        if(rect.y<lvl.y+lvl.h/2) dir="D";
//        if(rect.y>lvl.y+lvl.h/2+100) dir="U";

        return;
    }


    static bool hor_mov;
    static bool ver_mov;

    hor_mov=false;
    ver_mov=false;





    if (keystate[SDL_SCANCODE_W]) { //sprite movement using WSAD
        ver_mov = !ver_mov;
        clear_dir();
        dir[1]='U';
    }
    if (keystate[SDL_SCANCODE_S]) {
        ver_mov = !ver_mov;
        clear_dir();
        dir[1]='D';
    }
    if (keystate[SDL_SCANCODE_A]) {
        hor_mov = !hor_mov;
        if(!ver_mov) clear_dir();
        dir[0]='L';
    }
    if (keystate[SDL_SCANCODE_D]) {
        hor_mov = !hor_mov;
        if(!ver_mov)clear_dir();
        dir[0]='R';
    }


    //stops movement if opposite directions are pressed
    hor_mov || ver_mov ? mov=true : mov=false;


}

/*
 * void Player::animate()
 *
 *  manages animation across sprite sheet with sprite rect
 *  limits animation rate of sprite
 *
 *  parameters: none
 */

void Player::animate() {



    if (hit) { //flash for 20 frames if hit
        invincible_time = 20;
        hit = false;
    }

    frametime++;
    if (frametime >= 4) {                //check for movement && slow down sprite frame rate

        if (dir[1] == 'U') {                //set direction of sprite L:left R:right D:down U:up
            sprite.y = (sprite.h) * 3;
        } else if (dir[1] == 'D' ) {
            sprite.y = (sprite.h) * 0;
        } else if (dir[0] == 'L') {
            sprite.y = (sprite.h) * 1;
        } else if (dir[0] == 'R') {
            sprite.y = (sprite.h) * 2;
        }

        if (mov) {
            sprite.x += sprite.w;                   //advance across sprite sheet
            if (sprite.x + sprite.w >= sheet_w)
                sprite.x = 0;
        }

        if (invincible_time > 0)
            invincible_time--;

        frametime = 0;
    }
}

/*
 * void Player::render()
 *
 * applies changes to the main renderer
 *
 * parameters: none
 *
 */
void Player::render(){

    if(invincible_time%2==0)
        SDL_RenderCopy(renderer, texture, &sprite, &disp_rect);
}

void Player::slide(SDL_Rect focus){

    static int x=focus.x;
    static int y=focus.y;

    if(!centered) {
        if (rect.y > y)
            dir[1] = 'D';
        else if (rect.y < y)
            dir[1] = 'U';
        else if (rect.x > x)
            dir[0] = 'R';
        else if (rect.x < x)
            dir[0] = 'L';
    }
    clear_dir();

    ///forces player movement
    if(          focus.x+rect.w/2>rect.x &&
                 focus.x<rect.x+rect.w &&
                 focus.y+rect.h/2>rect.y &&
                 focus.y<rect.y+rect.h) {

        rect.x = focus.x - rect.w / 2;
        rect.y = focus.y - rect.h / 2;

        centered=true;

        if (rect.y > y)
            dir[1] = 'D';
        else if (rect.y < y)
            dir[1] = 'U';
        else if (rect.x > x)
            dir[0] = 'R';
        else if (rect.x < x)
            dir[0] = 'L';

        y = rect.y;
        x = rect.x;
    }
}

void Player::slide(bool s){
    centered=s;
    sliding=s;
}


#endif //SDL_TEST_PLAYER_H
