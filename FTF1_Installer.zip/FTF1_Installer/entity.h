//
// Created by mattr on 10/12/2017.
//

#ifndef FTF1_ENTITY_H
#define FTF1_ENTITY_H

#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include <random>
#include "loader.h"

std::ofstream out;

class Entity{
    protected:

    SDL_Rect rect;
    SDL_Rect disp_rect;
    SDL_Rect sprite;
    SDL_Rect lvl;
    SDL_Texture *texture;
    SDL_Renderer *renderer;


    unsigned int frametime;

    int sheet_w, sheet_h;
    int num_of_frames, num_of_dir;

    std::string type;


    public:
    Entity(){};
    Entity(int x, int y, SDL_Renderer *rend,const std::string type);
    ~Entity();

    static bool collision(Entity &e1, Entity &e2);
    void update(int camera_x, int camera_y);
    bool bind_to_lvl();
    void render();
    virtual void animate(){};
    virtual bool touchable(){return true;};
    virtual void collision(Entity &e){};

    void setLevelSize(SDL_Rect level);
    void setSprite(const std::string type);
    void setDisplay(int x, int y);
    void setType(std::string s);

    SDL_Rect getRect();
    std::string getType();

};
/*
 *Entity::Entity(int x, int y, SDL_Renderer *rend, const char* path)
 *
 * sets the renderer for the entity
 * retrieves the sprite for the entity
 * sets x/y position on the world
 *
 * parameters:
 *      int x:              x coordinate of starting position
 *      int y:              y coordinate of starting position
 *      SDl_Renderer *rend: main window renderer
 *      const char* path:   file location of the sprite
 */
Entity::Entity(int x, int y, SDL_Renderer *rend, const std::string type) {

    renderer=rend;

    setSprite(type);

    rect.x=x;
    rect.y=y;
    rect.w=32;      //overwritten by sub classes
    rect.h=32;      //
    disp_rect=rect; //
    sprite={0,0,0,0};//
    SDL_QueryTexture(texture, NULL,NULL, &sprite.w, &sprite.h);

    frametime=0;
}


/*
 * bool Entity::collision(Entity &e1, Entity &e2)  !!!!STATIC FUNCTION!!!!
 *
 * checks position rect of main entities to see if they are colliding
 * calls collision function for each entity individually
 *
 * parameters:
 *      Entity &e1: first entity for collision checking
 *      Entity &e2: second entity
 */
bool Entity::collision(Entity &e1, Entity &e2) {
//    out<<e1.getRect().x<<"x"<<e2.getRect().x<<" "<<e1.getRect().y<<"y"<<e2.getRect().y<<" ";
//    out<<e1.getRect().w<<"w"<<e2.getRect().w<<" "<<e1.getRect().h<<"h"<<e2.getRect().h<<std::endl;

    if(e1.getRect().x<e2.getRect().x+e2.getRect().w &&  //checks to see if rects have any overlap
       e1.getRect().x+e1.getRect().w >e2.getRect().x &&
       e1.getRect().y<e2.getRect().y+e2.getRect().h &&
       e1.getRect().y+e1.getRect().h>e2.getRect().y &&
       e1.touchable() && e2.touchable() )               //makes sure collision is possible based on state
    {
        e1.collision(e2);
        e2.collision(e1);
        return true;
    }
}
/*
 * void Entity::update(int camera_x, int camera_y)
 *
 * restrains entity to the level and sets its place in the camera
 *
 * parameters:
 *      int camera_x, camera_y: coordinates of the camera rect
 */

void Entity::update(int camera_x, int camera_y) {

    bind_to_lvl();

    setDisplay(camera_x, camera_y);
}

/*
 * void Entity::bind_to_lvl()
 *
 * constrains entity rect to level boundaries
 *
 * parameters: none
 */

bool Entity::bind_to_lvl() {
    bool bound=false;
    if(rect.x<=lvl.x) {                           //stop rectangle at edges
        rect.x = lvl.x;
        bound=true;
    }
    if(rect.y<=lvl.y) {
        rect.y = lvl.y;
        bound=true;
    }
    if(rect.x+rect.w>=lvl.w+lvl.x) {
        rect.x = lvl.w + lvl.x - rect.w;
        bound=true;
    }
    if(rect.y+rect.h>=lvl.h+lvl.y) {
        rect.y = lvl.h + lvl.y - rect.h;
        bound=true;
    }
    return bound;
}

/*
 * void Entity::render()
 *
 * applies changes to main renderer
 *
 * parameters: none
 */
void Entity::render() {
    SDL_RenderCopy(renderer, texture, &sprite, &disp_rect);
}

/*
 * void Entity::setLevelSize(SDL_Rect level)
 *
 *  sets lvl rect in entity to the size of the room
 *
 *  parameters:
 *      SDL_Rect level: rect representing the bounds of the room
 */
void Entity::setLevelSize(SDL_Rect level) {
    lvl.x=level.x;
    lvl.y=level.y;
    lvl.w=level.w;
    lvl.h=level.h;
}


/*
 * void Entity::setSprite(const char *path)
 *
 *  retrieves the sprite from memory and sets it as the entity texture
 *  displays a window on failure
 *
 *  parameters:
 *      const char* path: file path of the sprite
 *
 */
void Entity::setSprite(const std::string type) {
    setType(type);
   texture=LOAD->get_texture(type);
}

/*
 *void Entity::setDisplay(int x, int y)
 *
 * aligns the displaying rect in the camera
 *
 * parameters:
 *      int x, int y: x/y coord of camera rect
 */

void Entity::setDisplay(int x, int y){
    disp_rect.x=rect.x-x;       //center the displaying sprite
    disp_rect.y=rect.y-y;
}



void Entity::setType(std::string s) {
    type=s;
}


SDL_Rect Entity::getRect() {return rect;}

/*
 * Entity::~Entity()
 *
 * de-allocates the texture
 *
 * parameters
 */

std::string Entity::getType() {return type;}

Entity::~Entity() {
    if(texture)SDL_DestroyTexture(texture);
    texture=NULL;
    renderer=NULL;
}
#endif //FTF1_ENTITY_H
